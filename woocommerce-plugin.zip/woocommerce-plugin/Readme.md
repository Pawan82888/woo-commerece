=== WooCommerce CloudBanking Payment Gateway ===

Tags: credit card, CloudBanking, woocommerce
woocommerce version: 3.2.2
wordpress version: 4.8.1

Take credit card payments on your store using CloudBanking.

== Description ==

Accept Visa, MasterCard, American Express, Discover, JCB, Diners Club, and more cards directly on your store with the CloudBanking payment gateway for WooCommerce.

= Take Credit card payments easily and directly on your store =

The CloudBanking plugin extends WooCommerce allowing you to take payments directly on your store via cloubanking’s API.

CloudBanking is available in:

* in all countries

CloudBanking is a simple way to accept payments online. With CloudBanking you can accept Visa, MasterCard, American Express, directly on your store.

= Why choose CloudBanking? =

Cloud Banking provides its customers with an easy to use Virtual Terminal. This allows you to take credit card payments on virtually any internet enabled device with a touchscreen or keyboard.

The virtual terminal is a safe and secure way to process ad-hoc payments  for your customers, settled directly to your account the same day.

Cloud Banking provides our clients with a direct connection to our partner banks which means that Cloud Banking can provide a quick, secure and seamless front end to process your payments directly through the bank.

Importantly, we do not hold your money or touch it in any way, which allows Cloud Banking to process your money at the speed of Bank.


== Installation ==

Please note, v2 of this gateway requires updated WooCommerce.

You can download an [older version of this gateway for older versions of WooCommerce from here]().//change

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don’t need to leave your web browser. To
do an automatic install of, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type “WooCommerce-CloudBanking” and click Search Plugins. Once you’ve found our plugin you can view details about it such as the point release, rating and description. Most importantly of course, you can install it by simply clicking "Install Now".

just update your composer once.

= Manual installation =

The manual installation method involves downloading our plugin and uploading it to your web server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).



