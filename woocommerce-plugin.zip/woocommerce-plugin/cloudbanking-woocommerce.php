<?php
/*
Plugin Name: CloudBanking Gateway
Plugin URI: 
Description: Extends WooCommerce by Adding the CloudBanking Gateway.
Version: 1.0
Author: pawan
Author URI: #
*/

// Include our Gateway Class and register Payment Gateway with WooCommerce
add_action( 'plugins_loaded', 'cloudbanking_init', 0 );
function cloudbanking_init() {
	// If the parent WC_Payment_Gateway class doesn't exist
	// it means WooCommerce is not installed on the site
	// so do nothing
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;
	
	// If we made it this far, then include our Gateway Class
	include_once( 'cloudbanking-gateway.php' );

	// Now that we have successfully included our class,
	// Lets add it too WooCommerce
	add_filter( 'woocommerce_payment_gateways', 'add_gateway_name' );
	function add_gateway_name( $methods ) {
		$methods[] = 'CloudBanking_Gateway';
		return $methods;
	}
}

// Add custom action links
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'cloudbankung_action_links' );
function cloudbankung_action_links( $links ) {
	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout' ) . '">' . __( 'Settings', 'cloudbanking' ) . '</a>',
	);

	// Merge our new link with the default ones
	return array_merge( $plugin_links, $links );	
}