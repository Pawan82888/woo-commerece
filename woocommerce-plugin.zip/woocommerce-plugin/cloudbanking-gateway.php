<?php

require_once(__DIR__ . '/vendor/autoload.php');

use Omnipay\Common\CreditCard;
use Omnipay\Omnipay;
/* CloudBnaking Payment Gateway Class */

class CloudBanking_Gateway extends WC_Payment_Gateway {

	// Setup our Gateway's id, description and other values
	function __construct() {

		// The global ID for this Payment method
		$this->id = "cloudbanking";

		// The Title shown on the top of the Payment Gateways Page next to all the other Payment Gateways
		$this->method_title = __( "CloudBanking-Gateway", 'cloudbanking' );

		// The description for this Payment Gateway, shown on the actual Payment options page on the backend
		$this->method_description = __( "CloudBaking Payment Gateway Plug-in for WooCommerce", 'cloudbanking' );

		// The title to be used for the vertical tabs that can be ordered top to bottom
		$this->title = __( "CloudBanking", 'cloudbanking' );

		// If you want to show an image next to the gateway's name on the frontend, enter a URL to an image.
		$this->icon = null;

		// Bool. Can be set to true if you want payment fields to show on the checkout 
		// if doing a direct integration, which we are doing in this case
		$this->has_fields = true;

		// Supports the default credit card form
		$this->supports = array( 'default_credit_card_form', 'refunds' );

		// This basically defines your settings which are then loaded with init_settings()
		$this->init_form_fields();

		// After init_settings() is called, you can get the settings and load them into variables, e.g:
		// $this->title = $this->get_option( 'title' );
		$this->init_settings();
		
		// Turn these settings into variables we can use
		foreach ( $this->settings as $setting_key => $value ) {
			$this->$setting_key = $value;
		}
		
		// Lets check for SSL
		add_action( 'admin_notices', array( $this,	'do_ssl_check' ) );
		
		// Save settings
		if ( is_admin() ) {
			// Versions over 2.0
			// Save our administration options. Since we are not going to be doing anything special
			// we have not defined 'process_admin_options' in this class so the method in the parent
			// class will be used instead
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		}		
	} // End __construct()

	// Build the administration fields for this specific Gateway
	public function init_form_fields() {
        $this->form_fields = array(
			'enabled'        => array(
				'title'   => __( 'Enable / Disable', 'cloudbanking' ),
				'label'   => __( 'Enable this payment gateway', 'cloudbanking' ),
				'type'    => 'checkbox',
				'default' => 'no',
			),
			'title'          => array(
				'title'   => __( 'Title', 'cloudbanking' ),
				'type'    => 'text',
				'default' => __( 'CloudBanking', 'cloudbanking' ),
			),
			'description'    => array(
				'title'   => __( 'Description', 'cloudbanking' ),
				'type'    => 'textarea',
				'default' => __( 'Pay securely using your credit card ', 'cloudbanking' ),
				'css'     => 'max-width:350px;',
			),
			'authkey' => array(
				'title'       => __( 'Auth Key', 'cloudbanking' ),
				'type'        => 'text',
				'description' => __( 'Enter your CloudBanking Authkey.', 'cloudbanking' ),
			),
			'apiVersion'    => array(
				'title'       => __( 'Api Version', 'cloudbanking' ),
				'type'        => 'text',
				'description' => __( 'Enter your CloudBanking Apiversion.', 'cloudbanking' ),
			),
			'customerid'    => array(
				'title'       => __( 'Customer Id', 'cloudbanking' ),
				'type'        => 'text',
				'description' => __( 'Enter your CloudBanking Customer ID.', 'cloudbanking' ),
			),
		);
	}
	
	// Submit payment and handle response
	public function process_payment( $order_id ) {
		$customer_order = new WC_Order( $order_id );
		$card = $this->createcard($customer_order);
		$gateway = $this->gateway_instance();
		
		$gateway->setParameter('card', $card);
		$createCardRequest = $gateway->createCard();
		$cardCreateResponse = $createCardRequest->send();

		if ($cardCreateResponse->isSuccessful()) {
			// Process transaction
			$cardToken = $cardCreateResponse->getToken();
			$total_amount = $customer_order->order_total;
			$transaction = $gateway->purchase(array(	  
					'cardReference' 		=> $cardToken,
					'amount'     			=> $total_amount,
					'transactionId'			=> $order_id,
			));

			$response = $transaction->send();
			if ($response->isSuccessful()) {
				// echo "Purchase transaction was successful!\n";
				$banktransactionid = $response->getTransactionReference();
				global $woocommerce;
				$customer_order->payment_complete($banktransactionid);
				// Add the card token for use in refund flow
				update_post_meta( $order_id, '_cloudbanking_card_token', $cardToken );
				$woocommerce->cart->empty_cart();
				$customer_order->add_order_note(
					sprintf("Cloudbanking Credit Card payment completed with Transaction Id of '%s'", $banktransactionid)
				);
				unset($_SESSION['order_awaiting_payment']);
				// Return thankyou redirect
				return array(
					'result' => 'success',
					'redirect' => $this->get_return_url( $customer_order )
				);
			}
			else {
				$customer_order->add_order_note(sprintf("Cloudbanking Credit Card Payment Failed with message: '%s'", $response->getMessage()));
			}
		}
		else {
			$customer_order->add_order_note(sprintf("Cloudbanking create card Failed with message: '%s'", $cardCreateResponse->getMessage()));
		}
	}

	// Add method to handle refund
	
    
    public function gateway_instance(){
            $gateway = Omnipay::create('CloudBanking');
            $gateway->setAuthkey( $this->authkey );
            $gateway->setApiVersion( $this->apiVersion );
            $gateway->setCustomerReference( $this->customerid );
            return $gateway;
    }
	
	public function createcard( $customer_order ) {
		
		$card = new CreditCard();

		// Card details
		$card->setNumber($_POST['cloudbanking-card-number']);
		$expiryDate = date_create_from_format('m / y', $_POST['cloudbanking-card-expiry']);
		$card->setExpiryYear($expiryDate->format('y'));
		$card->setExpiryMonth($expiryDate->format('m'));
		$card->setCvv($_POST['cloudbanking-card-cvc']);
		$card->setEmail($customer_order->billing_email);

		// Billing details
		$card->setBillingFirstName($customer_order->billing_first_name);
		$card->setBillingLastName($customer_order->billing_last_name);
		$card->setBillingAddress1($customer_order->billing_address_1);
		$card->setBillingAddress2($customer_order->billing_address_2);
		$card->setBillingCity($customer_order->billing_city);
		$card->setBillingCountry($customer_order->billing_country);
		$card->setBillingState($customer_order->billing_state);
		$card->setBillingPhone($customer_order->billing_phone);
		$card->setBillingCompany($customer_order->billing_company);
		$card->setBillingPostcode($customer_order->billing_postcode);
		$card->setBillingPhone($customer_order->billing_phone);
	
		// Shipping details
		$card->setShippingFirstName($customer_order->shipping_first_name);
		$card->setShippingLastName($customer_order->shipping_last_name);
		$card->setShippingAddress1($customer_order->shipping_address_1);
		$card->setShippingCity($customer_order->shipping_city);
		$card->setShippingCountry($customer_order->shipping_country);
		$card->setShippingState($customer_order->shipping_state);
		$card->setShippingCompany($customer_order->shipping_company);
		$card->setShippingPostcode($customer_order->shipping_postcode);
		$card->setShippingPhone($customer_order->shipping_phone);
		return $card;
	}

	/**
     * Process refund.
     *
     * If the gateway declares 'refunds' support, this will allow it to refund.
     * a passed in amount.
     *
     * @param  int $order_id
     * @param  float $amount
     * @param  string $reason
     * @return boolean True or false based on success, or a WP_Error object.
     */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$gateway = $this->gateway_instance();
		$customer_order = new WC_Order( $order_id );
		$transactionId = $customer_order->get_transaction_id();
		$cardToken = get_post_meta( $order_id, '_cloudbanking_card_token', true );

		$refundRequest = $gateway->refund(array(	  
			'cardReference' 		=> $cardToken,
			'transactionReference'	=> $transactionId,
		));
		$refundResponse = $refundRequest->send();
		if ($refundResponse->isSuccessful()) {
			$customer_order->add_order_note(sprintf("Cloudbanking refund successful! Date: '%s', Refund Id: '%s', Refund Amount: '%s'",
				$refundResponse->getRefundDate(),
				$refundResponse->getRefundId(),
				$refundResponse->getAmountRefunded()));
			return true;
		}
		else {
			$customer_order->add_order_note(sprintf("Cloudbanking refund Failed with message: '%s'",
				$refundResponse->getMessage()));
			return false;
		}
	}
	
	 // Validate fields
	public function validate_fields() {
		return true;
	}
	
	// Check if we are forcing SSL on checkout pages
	// Custom function not required by the Gateway
	public function do_ssl_check() {
		if( $this->enabled == "yes" ) {
			if( get_option( 'woocommerce_force_ssl_checkout' ) == "no" ) {
				echo "<div class=\"error\"><p>". sprintf( __( "<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href=\"%s\">forcing the checkout pages to be secured.</a>" ), $this->method_title, admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) ."</p></div>";	
			}
		}		
	}

} 